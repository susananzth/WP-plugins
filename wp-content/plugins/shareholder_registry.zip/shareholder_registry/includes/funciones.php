<?php
function shareholder_registry_filtrar_preguntas($llave){
    return strpos($llave, 'qb_');
}
?>