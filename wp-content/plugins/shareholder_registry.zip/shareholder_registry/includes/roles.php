<?php
function shareholder_registry_crear_role() {
	add_role( 'shareholder_registry', 'Shareholder' );
}

function shareholder_registry_remover_role() {
	remove_role( 'shareholder_registry', 'Shareholder' );
}
function shareholder_registry_agregar_capabilities() {
	$roles = array( 'administrator', 'editor', 'shareholder_registry' );
	foreach( $roles as $the_role ) {
		$role = get_role( $the_role );
		$role->add_cap( 'read' );
		$role->add_cap( 'edit_Shareholders' );
		$role->add_cap( 'publish_Shareholders' );
		$role->add_cap( 'edit_published_Shareholders' );
        $role->add_cap( 'edit_other_Shareholders' );
	}
	$manager_roles = array( 'administrator', 'editor' );
	foreach( $manager_roles as $the_role ) {
		$role = get_role( $the_role );
		$role->add_cap( 'read_private_Shareholders' );
		$role->add_cap( 'edit_others_Shareholders' );
		$role->add_cap( 'edit_private_Shareholders' );
		$role->add_cap( 'delete_Shareholders' );
		$role->add_cap( 'delete_published_quizes' );
		$role->add_cap( 'delete_private_Shareholders' );
		$role->add_cap( 'delete_others_Shareholders' );
	}
}
function shareholder_registry_remover_capabilities() {
	$manager_roles = array( 'administrator', 'editor' );
	foreach( $manager_roles as $the_role ) {
		$role = get_role( $the_role );
		$role->remove_cap( 'read' );
		$role->remove_cap( 'edit_Shareholders' );
		$role->remove_cap( 'publish_Shareholders' );
		$role->remove_cap( 'edit_published_Shareholders' );
		$role->remove_cap( 'read_private_Shareholders' );
		$role->remove_cap( 'edit_others_Shareholders' );
		$role->remove_cap( 'edit_private_Shareholders' );
		$role->remove_cap( 'delete_Shareholders' );
		$role->remove_cap( 'delete_published_Shareholders' );
		$role->remove_cap( 'delete_private_Shareholders' );
		$role->remove_cap( 'delete_others_Shareholders' );
	}
}
?>