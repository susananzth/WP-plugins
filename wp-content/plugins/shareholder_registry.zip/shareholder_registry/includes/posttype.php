<?php
if(! defined('ABSPATH')) exit;
/* Para que no puedan acceder a este archivo colocando la url */
function shareholder_registry_post_type() {
    $labels = array(
        'name'                  => _x( 'Shareholder', 'Post type general name', 'shareholder_registry' ),
        'singular_name'         => _x( 'Shareholder', 'Post type singular name', 'shareholder_registry' ),
        'menu_name'             => _x( 'Shareholders', 'Admin Menu text', 'shareholder_registry' ),
        'name_admin_bar'        => _x( 'Shareholder', 'Add New on Toolbar', 'shareholder_registry' ),
        'add_new'               => __( 'Add new', 'shareholder_registry' ),
        'add_new_item'          => __( 'Add new Shareholder', 'shareholder_registry' ),
        'new_item'              => __( 'New Shareholder', 'shareholder_registry' ),
        'edit_item'             => __( 'Edit Shareholder', 'shareholder_registry' ),
        'view_item'             => __( 'See Shareholder', 'shareholder_registry' ),
        'all_items'             => __( 'All Shareholders', 'shareholder_registry' ),
        'search_items'          => __( 'Find Shareholders', 'shareholder_registry' ),
        'parent_item_colon'     => __( 'Father Shareholders:', 'shareholder_registry' ),
        'not_found'             => __( 'No encontrados.', 'shareholder_registry' ),
        'not_found_in_trash'    => __( 'No encontrados.', 'shareholder_registry' ),
        'featured_image'        => _x( 'Imagen Destacada', '', 'shareholder_registry' ),
        'set_featured_image'    => _x( 'Añadir imagen destacada', '', 'shareholder_registry' ),
        'remove_featured_image' => _x( 'Borrar imagen', '', 'shareholder_registry' ),
        'use_featured_image'    => _x( 'Usar como imagen', '', 'shareholder_registry' ),
        'archives'              => _x( 'Shareholders Archivo', '', 'shareholder_registry' ),
        'insert_into_item'      => _x( 'Insertar en Shareholder', '', 'shareholder_registry' ),
        'uploaded_to_this_item' => _x( 'Cargado en este Shareholder Registrys', '', 'shareholder_registry' ),
        'filter_items_list'     => _x( 'Filtrar Shareholders por lista', '”. Added in 4.4', 'shareholder_registry' ),
        'items_list_navigation' => _x( 'Navegación de Shareholders', '', 'shareholder_registry' ),
        'items_list'            => _x( 'Lista de Shareholders', '', 'shareholder_registry' ),
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        /* Muesta la opcion */
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'Shareholders' ),
        'capability_type'    => array('Shareholder', 'Shareholders'),
        /* Posicion en la que se muestra en el menú de wordpress */
        'menu_position'      => 6,
        /* Ícono */
        'menu_icon'          => 'dashicons-welcome-learn-more',
        'has_archive'        => false,
        /* Si quiero que se muestre por orden de más nuevo a más viejo o por herarquía */
        'hierarchical'       => false,
        /* Los diferentes elementos que se muestran en el editor */
        'supports'           => array( 'title', 'editor'),
        'map_meta_cap'       => true
    );
    /* Le doy nombre al plugin y le paso los argumentos */
    register_post_type( 'Shareholders', $args );
}

add_action( 'init', 'shareholder_registry_post_type' );

/*
* Flush Rewrite
*/
function shareholder_registry_rewrite_flush(){
    shareholder_registry_post_type();
    flush_rewrite_rules();
}
?>