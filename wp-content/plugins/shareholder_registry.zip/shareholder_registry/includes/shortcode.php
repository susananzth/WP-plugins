<?php
if(! defined('ABSPATH')) exit;

/*
* Crea un Shortcode, uso: [shareholder_registry]
*/
function shareholder_registry_shortcode(){
?>
    <div>
        <form>
            <h3>REGISTRO DE ACCIONISTAS</h3>
            <div class="form-row form-row-first" id="billing_first_name_field" data-priority="">
                <label for="billing_first_name" class="">Nombres&nbsp;<abbr class="required" title="required">*</abbr></label>
                <input type="text" class="input-text " name="billing_first_name" id="billing_first_name" placeholder=""  value="" autocomplete="Nombres" required="required" />
            </div>
            
            <div class="form-row form-row-last" id="billing_last_name_field" data-priority="1">
                <label for="billing_last_name" class="">Apellidos&nbsp;<abbr class="required" title="required">*</abbr></label>
                <input type="text" class="input-text " name="billing_last_name" id="billing_last_name" placeholder=""  value="" autocomplete="Apellido" required="required"/>
            </div>
            
            <div class="form-row form-row-wide" id="billing_fechaing" data-priority="2">
                <label for="billing_fechaing" class="">Fecha&nbsp;<abbr class="required" title="required">*</abbr></label>
                <input type="date" class="input-text " name="billing_fechaing" id="billing_fechaing" placeholder=""  value="" autocomplete="fecha ingreso" required="required"/>
            </div>
            
            <div class="form-row form-row-wide" id="billing_company_field" data-priority="2">
                <label for="billing_company" class="">Cédula de Identificación&nbsp;<abbr class="required" title="required">*</abbr></label><input type="text" class="input-text " name="billing_company" id="billing_company" placeholder=""  value="" autocomplete="identificacion" required="required"/>
            </div>
            
            <div class="form-row form-row-wide" id="billing_country_field" data-priority="3">
                <label for="billing_country" class="">País&nbsp;<abbr class="required" title="required">*</abbr></label>
                <select name="billing_country" id="billing_country" class="input-text" autocomplete="country" style="width: 100% !important; ">
                    <option value="<?php echo $conpais->Codigo ?>"><?php echo $conpais->Pais ?></option>
                    <?php foreach ($conpaises as $conpaise){ ?>
                        <option value="<?php echo $conpaise->Codigo; ?>" ><?php echo $conpaise->Pais ?></option>
                    <?php } ?>
                </select>
            </div>
            
            <div class="form-row form-row-wide" id="billing_state_field" data-priority="7">
                <label for="billing_state" class="">Estado/Departamento&nbsp;<abbr class="required" title="required">*</abbr></label>
                <select name="billing_state" id="billing_state" class="state_select " autocomplete="address-level1" data-placeholder="" style="width: 100% !important; ">
                    <option value="">Seleccione...&hellip;</option>
                    <?php foreach ($conciudades as $conciudad) { ?>
                        <option value="<?php echo $conciudad->CuidadID; ?>">
                            <?php echo $conciudad->CiudadNombre ?> 
                        </option>
                    <?php } ?>
                </select>
            </div>
            
            <div class="form-row form-row-wide address-field" id="billing_city_field" data-priority="6">
                <label for="billing_city" class="">Provincia/Municipio&nbsp;<abbr class="required" title="required">*</abbr></label>
                <input type="text" class="input-text " name="billing_city" id="billing_city" placeholder=""  value="" autocomplete="address-level2" required="required"/>
            </div>
            
            <div class="form-row form-row-wide address-field" id="billing_address_1_field" data-priority="4">
                <label for="billing_address_1" class="">Dirección&nbsp;<abbr class="required" title="required">*</abbr></label>
                <input type="text" class="input-text " name="billing_address_1" id="billing_address_1" placeholder="Nombre de la calle y número de casa" autocomplete="" required="required" />
            </div>
            
            <div class="form-row form-row-wide address-field" id="billing_postcode_field" data-priority="8">
                <label for="billing_celular" class="">Celular&nbsp;<abbr class="required" title="required">*</abbr></label>
                <input type="text" class="input-text " name="billing_celular" id="billing_celular" placeholder=""  value="" autocomplete="postal-code" required="required" />
                <a><div>validar</div></a>
            </div>
            
            <div class="form-row form-row-wide" id="billing_email_field" data-priority="">
                <label for="billing_email" class="">E-mail&nbsp;<abbr class="required" title="required">*</abbr></label>
                <input type="text" class="input-text " name="billing_email" id="billing_email" placeholder="Email" required="required"/>
            </div>
            
            <div class="form-row form-row-wide address-field" id="billing_invita" data-priority="8">
                <label for="billing_invita" class="">Usuario que invita&nbsp;<abbr class="required" title="required">*</abbr></label>
                <input type="text" class="input-text " name="billing_invita" id="billing_invita" autocomplete="Sponsor" placeholder="Sponsor" required="required" />
            </div>
            
            <div class="form-row form-row-wide address-field" id="billing_accion" data-priority="7">
                <label for="billing_accion" class="">Accion&nbsp;<abbr class="required" title="required">*</abbr></label>
                <select name="billing_accion" id="billing_accion" class="state_select " autocomplete="" data-placeholder="" style="width: 100% !important; ">
                    <option value="">Select tipo de accion&hellip;</option>
                    <?php foreach ( $fivesdrafts as $fivesdraft ) { ?>
                        <option value="<?php echo $fivesdraft->id_tiposaccionistas; ?>">
                            <?php echo $fivesdraft->nom_tiposaccionistas; ?> 
                        </option>
                    <?php } ?> 
                </select>
            </div>
            
            <div class="form-row form-row-wide address-field" id="img_up" data-priority="8">
                <label for="img_up" class="">Voucher&nbsp;<abbr class="required" title="required">*</abbr></label>
                <input type="file" class="input-text " name="img_up" id="img_up" required="required" />
            </div>
        </form>
    </div>
<?php
}
add_shortcode('shareholder_registry', 'shareholder_registry_shortcode')
?>