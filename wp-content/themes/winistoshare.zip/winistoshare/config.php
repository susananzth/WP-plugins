<?php
    define('DB_HOST', 'localhost');
    define('DB_USER', 'root');
    define('DB_PASSWORD', "");
    define('DB_NAME', 'wp-plugin');
    define('DB_CHARSET', 'utf8');
?>