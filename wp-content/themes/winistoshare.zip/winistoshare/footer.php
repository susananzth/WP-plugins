        </section><!-- /#global-content -->
		<footer id="main-footer">	
            <div class="contact">
                <div class="col-1 col-padding-1 text-left">
                    <p>Contáctanos</p>
                </div>
                <div class="row contacto">
                    <div class="col-3 col-xs col-padding-1 text-left">
                        <a href="https://www.facebook.com/WinPeru-Oficial-176076053110785/" target="_blank" type="text/html">
                            <span class="icon-facebook"></span>
                            Facebook.com
                        </a>
                    </div>
                    <div class="col-3 col-xs col-padding-1 text-left">
                        <a href="youtube.com" target="_blank" type="text/html">
                            <span class="icon-youtube"></span>
                            Youtube.com
                        </a>
                    </div>
                    <div class="col-3 col-xs col-padding-1 text-left">
                        <a href="mailto:sistemas@winhold.net?Subject=Contacto%20Sistemas" target="_top" type="text/html">
                            <span class="icon-mail_outline"></span>
                            sistemas@winhold.net
                        </a>
                    </div>
                    <div class="col-1 col-xs col-padding-1 text-left">
                        <a href="https://www.google.co.ve/maps/@-11.9958796,-77.0780084,19.75z?hl=es" target="_top" type="text/html">
                            <span class="icon-room"></span>
                            Urb. Covida, Jr Pataz #1253. Los Olivos. Lima, Perú
                        </a>
                    </div>
                </div>
            </div>
			<div class="footer-copyright">
				<?php _e('Todos los Derechos Reservados '); ?>&copy; <?php echo date('Y'); ?> <?php _e('WIN TECNOLOGIES INC S.A.'); ?>
                <!-- Obtengo el año actual y el título de la página y lo imprimo | I get the current year and the title of the page and print it -->
			</div><!-- /.footer-copyright -->
		</footer><!-- footer -->
	</div><!-- /#global-container -->
    <script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
    <script type="text/javascript" src="<?php bloginfo('template_url');?>/js/script.js"></script>
    <script type="text/javascript" src="<?php bloginfo('template_url');?>/js/jquery.js"></script>
    <?php wp_footer(); ?>
    <!-- Aquí llamo los script para cargar y ejecutar todas las funciones al final del footer. |
         I call the script to load and execute all the functions of the footer-->
</body>
</html>